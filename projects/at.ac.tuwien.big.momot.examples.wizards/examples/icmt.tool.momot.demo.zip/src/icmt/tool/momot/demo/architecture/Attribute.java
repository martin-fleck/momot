/**
 */
package icmt.tool.momot.demo.architecture;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see icmt.tool.momot.demo.architecture.ArchitecturePackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends Feature {
} // Attribute
